# ระบบออกใบเสร็จรับเงิน

แพ็กนี้พร้อมนำขึ้น GitHub Pages แบบ Static Website

## ไฟล์ที่ต้องอัปโหลดขึ้น GitHub

- `index.html`
- โฟลเดอร์ `assets`
- `.nojekyll`

ให้อัปโหลดไฟล์เหล่านี้ไว้ที่หน้าแรกของ Repository หรือใช้โฟลเดอร์นี้ทั้งโฟลเดอร์เป็นต้นทางของ Repository

## วิธีเผยแพร่ด้วย GitHub Pages

1. เข้า GitHub แล้วสร้าง Repository ใหม่ เช่น `receipt-app`
2. อัปโหลดไฟล์ทั้งหมดในโฟลเดอร์นี้ขึ้น Repository
3. เข้าเมนู `Settings`
4. เลือก `Pages`
5. ที่ `Build and deployment` เลือก `Deploy from a branch`
6. เลือก Branch เป็น `main`
7. เลือก Folder เป็น `/root`
8. กด `Save`
9. รอ GitHub สร้างเว็บ แล้วเปิด URL ที่ GitHub Pages แสดงให้

## ข้อสำคัญก่อนใช้งานจริง

เว็บชุดนี้เป็นเว็บไฟล์เดียวแบบ Static App ข้อมูลจะถูกเก็บใน Browser ของผู้ใช้งานผ่าน `localStorage`

ผลคือ:

- ถ้าผู้ใช้คนละเครื่อง ข้อมูลใบเสร็จจะไม่ใช่ฐานข้อมูลเดียวกัน
- ถ้าล้างข้อมูล Browser ข้อมูลใบเสร็จในเครื่องนั้นอาจหาย
- รหัส Admin ในเว็บ Static ไม่ปลอดภัยสำหรับระบบงานจริงที่เปิดสาธารณะ

ถ้าต้องการให้หลายคนใช้ระบบเดียวกันจริง ควรต่อฐานข้อมูลกลางและระบบ Login ฝั่ง Server เช่น Supabase, Firebase, หรือ Backend + Database

## บัญชีเริ่มต้น

- Admin username: `admin`
- Admin password: `admin123`

ควรเปลี่ยนระบบ Login ก่อนใช้งานจริงแบบสาธารณะ

